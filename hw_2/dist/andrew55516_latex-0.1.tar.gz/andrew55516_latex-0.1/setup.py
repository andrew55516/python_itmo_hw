from setuptools import setup, find_packages

setup(
    name="andrew55516_latex",
    version="0.1",
    packages=find_packages(),
    description="",
    long_description="",
    long_description_content_type='text/markdown',
    author="Андрей",
    author_email="",
    url="",
)
